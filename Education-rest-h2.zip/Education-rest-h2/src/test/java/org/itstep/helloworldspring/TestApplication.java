package org.itstep.helloworldspring;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Set;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestApplication {
    @Autowired
    private MockMvc mvc;// Mock  объект - это объект, специально для тестирования

    @Test
    @Order(1)
    public void index() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(equalTo("index")));
    }

    @Test
    @Order(2)// выводит всех студентов
    public void students() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/students")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(5)))
                .andExpect(jsonPath("$[0].lastname",
                        Matchers.equalTo("Bondarenko")))
        ;
    }

    @Test
    @Order(3)// выводит одного студента по id
    public void getStudentsById() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/students/{student_id}", 1)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.lastname", Matchers.equalTo("Bondarenko")))
                .andExpect(jsonPath("$.firstname", Matchers.equalTo("Stanislav")))
        ;

    }

    @ParameterizedTest // Создаем параметризованный тест
    @ValueSource(ints = {-1, 0, 1, 2, 3, 4, 5, Integer.MAX_VALUE})
    @Order(4)
    public void getStudentsById(int student_id) throws Exception {
        ResultActions actions = mvc.perform(MockMvcRequestBuilders.get("/students/{student_id}", student_id).
                accept(MediaType.APPLICATION_JSON));
        actions
                .andExpect(status().isOk());
        switch (student_id) {
            case 1:
                actions
                        .andExpect(jsonPath("$.lastname", Matchers.equalTo("Bondarenko")));
                break;
            case 2:
                actions
                        .andExpect(jsonPath("$.lastname", Matchers.equalTo("Gudova")));
                break;
            case 3:
                actions
                        .andExpect(jsonPath("$.lastname", Matchers.equalTo("Klimovich")));
                break;
            case 4:
                actions
                        .andExpect(jsonPath("$.lastname", Matchers.equalTo("Mineeva")));
                break;
            case 5:
                actions
                        .andExpect(jsonPath("$.lastname", Matchers.equalTo("Narushevich")));
                break;
            default:
                actions
                        .andExpect(content().string("null"));
        }
    }

    @Test
    @Order(5)
    public void postStudents() throws Exception {
        mvc.perform(
                        MockMvcRequestBuilders.post
                                        ("/students")
                                .content(asJsonString(new Students( 6L, "Sergeeva", "Arina")))
                                .contentType(MediaType.APPLICATION_JSON)
                                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                //.andExpect(status().isCreated())
                .andExpect(jsonPath("$.lastname", Matchers.equalTo("Sergeeva")))
                .andExpect(jsonPath("$.firstname", Matchers.equalTo("Arina")))

        ;
    }
    @Test
    @Order(6)
    public void putStudents() throws Exception {
        mvc.perform(
                        MockMvcRequestBuilders.post
                                        ("/students")
                                .content(asJsonString(new Students( 6L, "Mineeva", "Arina")))
                                .contentType(MediaType.APPLICATION_JSON)
                                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                //.andExpect(status().isCreated())
                .andExpect(jsonPath("$.lastname", Matchers.equalTo("Mineeva")))
                .andExpect(jsonPath("$.firstname", Matchers.equalTo("Arina")))

        ;
    }
    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Test
    @Order(7)
    public void deleteStudents() throws Exception
    {
        mvc.perform
                        ( MockMvcRequestBuilders.delete("/students/4", 4) )
                .andExpect(status().isOk());
    }

}

