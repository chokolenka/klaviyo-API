package org.itstep.helloworldspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BodyService {


    @Autowired
    BodyRepository bodyRepository;
    public List<Body> findAll(){
        return bodyRepository.findAll();
    }

    public Optional<Body> findById(Long body_id){
        return bodyRepository.findById(body_id);
    }

    // Для методов Post и Put метод будет один

    public Body save(Body body){
        return bodyRepository.save(body);
    }

    public void deleteById(Long body_id){
        bodyRepository.deleteById(body_id);
    }




}