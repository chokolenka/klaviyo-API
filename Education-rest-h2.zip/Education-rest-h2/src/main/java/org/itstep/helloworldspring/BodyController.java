package org.itstep.helloworldspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController // С помощью него выполняется обмен данными в формате json

public class BodyController {

    @Autowired // автоприсоединение
    BodyService bodyService; // Присоединяем сервер, который мы перед этим создали

    @GetMapping("/") // "/" отображение запроса,подразумевает 8080
    public String index(){
        return "index";
    }

    @GetMapping(value="/body") //отображение запроса
    public List<Body> findAll(){
        return bodyService.findAll();
    }


    @GetMapping(value="/body/{body_id}")
    public Optional<Body> findById(@PathVariable Long body_id){
        return bodyService.findById(body_id);
    }

    @PostMapping(value="/body")
    public Body post(@RequestBody Body body){
        return bodyService.save(body);
    }

    @PutMapping(value="/body/{body_id}")
    public Body update(@RequestBody Body newBody, @PathVariable Long body_id){
        return bodyService.findById(body_id).map(body->{
            body.setGroup_number(newBody.getGroup_number());
            body.setDate_of_join(newBody.getDate_of_join());
            return bodyService.save(body);
        }).orElseGet(()-> bodyService.save(newBody));
    }

    @DeleteMapping(value="/body/{body_id}")
    public void delete(@PathVariable Long body_id){
        bodyService.deleteById(body_id);
    }






}
