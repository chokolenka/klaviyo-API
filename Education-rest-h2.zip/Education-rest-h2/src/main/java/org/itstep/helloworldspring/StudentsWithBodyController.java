package org.itstep.helloworldspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController // С помощью него выполняется обмен данными в формате json

public class StudentsWithBodyController {

    @Autowired
    StudentsWithBodyService studentsWithBodyService; // Присоединяем сервер, который мы перед этим создали

    @GetMapping(value="/students_with_body")
    public List<StudentsWithBody> findAll(){
        return studentsWithBodyService.findAll();
    }

    @GetMapping(value="/students_with_body/{id}")
    public Optional<StudentsWithBody> findById(@PathVariable Long id){
        return studentsWithBodyService.findById(id);
    }

    @PostMapping(value="/students_with_body")
    StudentsWithBody createOrSave(@RequestBody StudentsWithBody studentsWithBody) {
        return studentsWithBodyService.save(studentsWithBody);
    }

    @PutMapping(value="/students_with_body/{id}")
    StudentsWithBody updateUser(@RequestBody StudentsWithBody newStudentsWithBody,
                        @PathVariable Long id) {
        return studentsWithBodyService.findById(id).map(studentsWithBody -> {
            studentsWithBody.setStudent_id(newStudentsWithBody.getStudent_id());
            studentsWithBody.setBody_id(newStudentsWithBody.getBody_id());
            return studentsWithBodyService.save(studentsWithBody);
        }).orElseGet(() -> studentsWithBodyService.save(newStudentsWithBody));

    }
;
    @DeleteMapping(value="/studentsWithBody/{id}")
    void deleteById(@PathVariable Long id) {
        studentsWithBodyService.deleteById(id);
        System.out.println("delete");
    }

}

