package org.itstep.helloworldspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentsWithBodyService {


    @Autowired
    StudentsWithBodyRepository studentsWithBodyRepository;

    public List<StudentsWithBody> findAll(){
        return studentsWithBodyRepository.findAll();
    }


    public Optional<StudentsWithBody> findById(Long id){return studentsWithBodyRepository.findById(id);
    }

    public StudentsWithBody save(StudentsWithBody studentsWithBody){return studentsWithBodyRepository.save(studentsWithBody);}

    public void deleteById(Long student_id){
        studentsWithBodyRepository.deleteById(student_id);
    }

}
