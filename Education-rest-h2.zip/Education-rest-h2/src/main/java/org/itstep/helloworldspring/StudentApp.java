package org.itstep.helloworldspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentApp {

    public static void main(String[] args) {
        SpringApplication.run(StudentApp.class, args);
    }

}

