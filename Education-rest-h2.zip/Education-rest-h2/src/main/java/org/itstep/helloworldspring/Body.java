package org.itstep.helloworldspring;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "body")

public class Body {
    @Id
    @Column(name = "body_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long body_id;
    private int date_of_join;
    private int group_number;

    @OneToMany(mappedBy="student_id")
    private Set<Students> students;

}

