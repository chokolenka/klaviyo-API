package org.itstep.helloworldspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController // С помощью него выполняется обмен данными в формате json

public class StudentsController {

    @Autowired
    StudentsService studentsService; // Присоединяем сервер, который мы перед этим создали

    @GetMapping(value="/students")
    public List<Students> findAll(){
        return studentsService.findAll();
    }

    @GetMapping(value="/students/{student_id}")
    public Optional<Students> findById(@PathVariable Long student_id){
        return studentsService.findById(student_id);
    }

    @PostMapping(value="/students")
    Students createOrSave(@RequestBody Students students) {
        return studentsService.save(students);
    }

    @PutMapping(value="/students/{student_id}")
    Students updateUser(@RequestBody Students newStudents,
                        @PathVariable Long student_id) {
        return studentsService.findById(student_id).map(students -> {
            students.setLastname(newStudents.getLastname());
            students.setFirstname(newStudents.getFirstname());
            return studentsService.save(students);
        }).orElseGet(() -> studentsService.save(newStudents));

    }

    @DeleteMapping(value="/students/{student_id}")
    void deleteById(@PathVariable Long student_id) {
        studentsService.deleteById(student_id);
        System.out.println("delete");
    }

}

