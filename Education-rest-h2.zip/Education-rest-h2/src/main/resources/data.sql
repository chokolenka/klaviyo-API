insert into students (lastname, firstname, student_id)
values ('Bondarenko', 'Stanislav', 1), ('Gudova', 'Milana', 2 ),
       ('Klimovich','Olga', 3 ), ('Mineeva','Arina', 4 ), ('Narushevich','Zlata', 5 );

insert into body (date_of_join, group_number, body_id)
values('2020', '112', 1 ), ('2020', '112', 2 ), ('2020',  '114',  3 ),
      ('2020',  '114',  4 ), ('2021', '108',  5 );

insert into students_with_body (student_id, body_id, id)
values (1, 1, 1 ), ( 2, 2, 2 ), (3, 3, 3 ), ( 4, 4, 4), ( 5, 5, 5);
