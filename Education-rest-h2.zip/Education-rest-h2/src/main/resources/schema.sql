drop table if exists student;
drop table if exists body;
drop table if exists students_with_body;

CREATE TABLE students (
                          student_id int NOT NULL AUTO_INCREMENT,
                          lastname varchar(45) NOT NULL,
                          firstname varchar(45) NOT NULL,
                          PRIMARY KEY (student_id)
);

CREATE TABLE body (
                      body_id int NOT NULL AUTO_INCREMENT,
                      student_id int,
                      date_of_join int,
                      group_number int,
                      foreign key (student_id) references body(body_id),
                      PRIMARY KEY (body_id)
);

CREATE TABLE students_with_body(
                                   id int NOT NULL AUTO_INCREMENT,
                                   student_id int,
                                   body_id int,
                                   foreign key (body_id) references students_with_body(id),
                                   foreign key (student_id) references students_with_body(id),
                                   PRIMARY KEY (id)
);


